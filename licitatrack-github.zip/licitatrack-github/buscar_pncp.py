#!/usr/bin/env python3
"""
LicitaTrack PRO — Buscador PNCP
Roda no GitHub Actions (sem CORS) e salva licitacoes.json
"""

import json
import requests
from datetime import datetime, timedelta, timezone

PALAVRAS_CHAVE = [
    'caminhão', 'caminhao', 'caminhoes', 'caminhões',
    'veículo pesado', 'veiculo pesado', 'truck',
    'basculante', 'pipa', 'betoneira', 'munck', 'guindaste',
    'cavalo mecânico', 'cavalo mecanico', 'semi-reboque', 'semireboque',
    'carreta', 'baú', 'bau', 'carga seca', 'graneleiro',
    'frigorífico', 'frigorifico', 'caçamba', 'cacamba',
]

HEADERS = {
    'Accept': 'application/json',
    'User-Agent': 'Mozilla/5.0 (compatible; LicitaTrackBot/1.0)',
}

BRT = timezone(timedelta(hours=-3))

def hoje_brt():
    return datetime.now(BRT)

def fmt_data(dt):
    if not dt:
        return None
    return dt.isoformat()

def parse_data(s):
    if not s:
        return None
    for fmt in ('%Y-%m-%dT%H:%M:%S', '%Y-%m-%dT%H:%M:%SZ', '%Y-%m-%dT%H:%M:%S%z', '%Y-%m-%d'):
        try:
            return datetime.strptime(s[:19], fmt[:len(s[:19])]).replace(tzinfo=BRT)
        except:
            pass
    return None

def contem_palavra_chave(texto):
    t = texto.lower()
    for p in PALAVRAS_CHAVE:
        if p.lower() in t:
            return p
    return None

def traduzir_modalidade(m):
    mapa = {
        'PREGAO_ELETRONICO': 'Pregão Eletrônico',
        'PREGAO_PRESENCIAL': 'Pregão Presencial',
        'CONCORRENCIA': 'Concorrência',
        'TOMADA_PRECOS': 'Tomada de Preços',
        'CONVITE': 'Convite',
        'DISPENSA': 'Dispensa',
        'INEXIGIBILIDADE': 'Inexigibilidade',
        'LEILAO': 'Leilão',
        'DIALOGO_COMPETITIVO': 'Diálogo Competitivo',
    }
    return mapa.get(str(m).upper().replace(' ', '_'), m or 'Pregão Eletrônico')

def normalizar_item(item, palavra_chave=''):
    agora = hoje_brt()

    data_ab_str = (item.get('dataAberturaProposta')
                   or item.get('dataEncerramentoProposta')
                   or item.get('dataFimRecebimentoProposta'))
    data_pub_str = item.get('dataPublicacaoPncp') or item.get('dataInclusao')

    data_ab  = parse_data(data_ab_str)
    data_pub = parse_data(data_pub_str) or agora

    situacao = 'encerrada'
    if data_ab:
        situacao = 'futura' if data_ab > agora else 'aberta'

    id_ = str(item.get('numeroControlePNCP') or item.get('id') or f"pncp-{hash(str(item))}")

    orgao = (
        (item.get('orgaoEntidade') or {}).get('razaoSocial')
        or (item.get('unidadeOrgao') or {}).get('nomeUnidade')
        or 'Órgão não informado'
    )
    uf = (
        (item.get('unidadeOrgao') or {}).get('ufSigla')
        or (item.get('unidadeOrgao') or {}).get('ufNome')
        or ''
    ).upper()[:2]
    municipio = (item.get('unidadeOrgao') or {}).get('municipioNome', '')

    hoje_data = agora.date()
    is_nova = data_pub.date() == hoje_data if data_pub else False

    return {
        'id': id_,
        'titulo': (item.get('objetoCompra') or item.get('descricao')
                   or item.get('objeto') or 'Licitação sem título'),
        'orgao': orgao,
        'uf': uf,
        'municipio': municipio,
        'modalidade': traduzir_modalidade(
            item.get('modalidadeNome') or item.get('modalidade') or ''
        ),
        'valor': item.get('valorTotalEstimado') or item.get('valorEstimado') or 0,
        'dataAbertura': fmt_data(data_ab),
        'dataPublicacao': fmt_data(data_pub),
        'dataEncerramento': fmt_data(parse_data(item.get('dataEncerramentoProposta'))),
        'situacao': situacao,
        'isNova': is_nova,
        'fonte': 'PNCP',
        'isSest': False,
        'link': item.get('linkEdital') or f"https://pncp.gov.br/app/editais/{id_}",
        'numero': item.get('numeroCompra') or item.get('numero') or id_,
        'palavraChave': palavra_chave,
    }

def buscar_pncp():
    agora = hoje_brt()
    d_ini = (agora - timedelta(days=30)).strftime('%Y%m%d')
    d_fim = agora.strftime('%Y%m%d')

    resultados = []
    ids_vistos = set()

    # Busca até 5 páginas (100 itens cada = 500 licitações recentes)
    for pagina in range(1, 6):
        url = (
            f"https://pncp.gov.br/api/pncp/v1/contratacoes/publicacoes"
            f"?dataInicial={d_ini}&dataFinal={d_fim}&tamanhoPagina=100&pagina={pagina}"
        )
        print(f"[PNCP] Página {pagina}: {url}")
        try:
            r = requests.get(url, headers=HEADERS, timeout=20)
            r.raise_for_status()
            raw = r.json()
        except requests.exceptions.HTTPError as e:
            print(f"[PNCP] Erro HTTP {e.response.status_code} na página {pagina}")
            break
        except Exception as e:
            print(f"[PNCP] Erro na página {pagina}: {e}")
            break

        # Extrai lista de itens
        if isinstance(raw, list):
            itens = raw
        elif isinstance(raw, dict):
            itens = (raw.get('data') or raw.get('items') or raw.get('resultado')
                     or raw.get('content') or raw.get('licitacoes')
                     or raw.get('publicacoes') or [])
        else:
            itens = []

        print(f"[PNCP] {len(itens)} itens recebidos na página {pagina}")

        if not itens:
            # Sem mais dados
            break

        encontrados = 0
        for item in itens:
            texto = ' '.join(filter(None, [
                item.get('objetoCompra'), item.get('descricao'),
                item.get('objeto'), item.get('nomeItem'),
                item.get('objetoLicitacao'),
            ]))
            kw = contem_palavra_chave(texto)
            if not kw:
                continue

            norm = normalizar_item(item, kw)
            if norm['id'] not in ids_vistos:
                ids_vistos.add(norm['id'])
                resultados.append(norm)
                encontrados += 1

        print(f"[PNCP] {encontrados} licitações de caminhões na página {pagina}")

        # Para se já temos bastante
        if len(resultados) >= 100:
            break

    return resultados

def main():
    print(f"[LicitaTrack] Iniciando busca — {hoje_brt().strftime('%d/%m/%Y %H:%M')} BRT")

    licitacoes = buscar_pncp()

    # Ordena: urgentes (<24h) → novas → futuras → abertas → encerradas
    agora = hoje_brt()
    def sort_key(l):
        da = parse_data(l.get('dataAbertura'))
        horas = (da - agora).total_seconds() / 3600 if da else float('inf')
        urgente = 0 if (0 < horas <= 24) else 1
        nova    = 0 if l.get('isNova') else 1
        sit_ord = {'aberta': 0, 'futura': 1, 'encerrada': 2}.get(l.get('situacao'), 3)
        return (urgente, nova, sit_ord, horas)

    licitacoes.sort(key=sort_key)

    saida = {
        'licitacoes': licitacoes,
        'total': len(licitacoes),
        'geradoEm': hoje_brt().isoformat(),
        'fonte': 'PNCP',
    }

    with open('licitacoes.json', 'w', encoding='utf-8') as f:
        json.dump(saida, f, ensure_ascii=False, indent=2)

    print(f"[LicitaTrack] ✅ {len(licitacoes)} licitações salvas em licitacoes.json")

if __name__ == '__main__':
    main()
