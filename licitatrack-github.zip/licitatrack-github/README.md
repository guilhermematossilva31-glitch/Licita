# 🚛 LicitaTrack PRO

Monitor de licitações públicas de caminhões e veículos pesados — PNCP ao vivo, sem CORS.

## Como funciona

```
GitHub Actions (a cada 15 min)
    → buscar_pncp.py busca o PNCP no servidor (sem CORS)
    → salva licitacoes.json no repositório
GitHub Pages serve index.html + licitacoes.json
    → browser lê JSON do mesmo domínio (sem CORS!)
```

## Setup (5 minutos)

### 1. Crie o repositório no GitHub

- Acesse github.com → **New repository**
- Nome sugerido: `licitatrack`
- Marque **Public** (necessário para GitHub Pages gratuito)
- Clique **Create repository**

### 2. Suba os arquivos

Pela interface web do GitHub, faça upload de todos os arquivos deste ZIP:
- `index.html`
- `licitacoes.json`
- `buscar_pncp.py`
- `.github/workflows/buscar.yml`

Ou pelo terminal:
```bash
git init
git add .
git commit -m "LicitaTrack PRO — setup inicial"
git remote add origin https://github.com/SEU_USUARIO/licitatrack.git
git push -u origin main
```

### 3. Ative o GitHub Pages

- Vá em **Settings → Pages**
- Source: **Deploy from a branch**
- Branch: **main** / **(root)**
- Clique **Save**

Aguarde ~1 minuto. Seu site estará em:
`https://SEU_USUARIO.github.io/licitatrack`

### 4. Execute o workflow pela primeira vez

- Vá em **Actions** no seu repositório
- Clique em **🚛 Buscar Licitações PNCP**
- Clique **Run workflow → Run workflow**
- Aguarde ~30 segundos

O `licitacoes.json` será preenchido com dados reais do PNCP e o site exibirá as licitações.

A partir daí, o workflow roda automaticamente a cada 15 minutos.

## Estrutura

```
licitatrack/
├── index.html              # Frontend — lê licitacoes.json
├── licitacoes.json         # Gerado automaticamente pelo Actions
├── buscar_pncp.py          # Script Python que busca o PNCP
└── .github/
    └── workflows/
        └── buscar.yml      # Configuração do GitHub Actions
```

## Personalização

Para adicionar palavras-chave, edite a lista `PALAVRAS_CHAVE` no `buscar_pncp.py`.

## Custo

**Gratuito.** O GitHub Actions free tier oferece 2.000 minutos/mês.
A cada execução de 15 em 15 minutos gastamos ~0,5 min → ~1.440 min/mês. Dentro do limite.
